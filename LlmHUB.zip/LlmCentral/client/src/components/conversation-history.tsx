import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { History, Trash2, MessageSquare } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import type { Conversation } from "@shared/schema";

const providerColors: Record<string, string> = {
  openai: "bg-emerald-100 text-emerald-700",
  claude: "bg-amber-100 text-amber-700",
  gemini: "bg-blue-100 text-blue-700",
  perplexity: "bg-indigo-100 text-indigo-700",
};

const providerNames: Record<string, string> = {
  openai: "OpenAI",
  claude: "Claude",
  gemini: "Gemini",
  perplexity: "Perplexity",
};

export function ConversationHistory() {
  const queryClient = useQueryClient();

  const { data: conversations = [], isLoading } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
  });

  const clearHistoryMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", "/api/conversations");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
  });

  const formatTimestamp = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return "Just now";
    if (diff < 3600000) return `${Math.floor(diff / 60000)} minutes ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
    return date.toLocaleDateString();
  };

  const truncateText = (text: string, maxLength: number = 100) => {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + "...";
  };

  if (isLoading) {
    return (
      <Card className="mt-8">
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-slate-200 rounded w-1/4"></div>
            <div className="space-y-3">
              <div className="h-20 bg-slate-200 rounded"></div>
              <div className="h-20 bg-slate-200 rounded"></div>
            </div>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="mt-8">
      <div className="p-6 border-b border-slate-100">
        <h2 className="text-lg font-semibold text-slate-900 flex items-center justify-between">
          <span className="flex items-center">
            <History className="text-slate-500 mr-2 h-5 w-5" />
            Recent Conversations
          </span>
          {conversations.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => clearHistoryMutation.mutate()}
              disabled={clearHistoryMutation.isPending}
              className="text-slate-500 hover:text-slate-700"
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </h2>
      </div>
      
      <div className="p-6">
        {conversations.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <MessageSquare className="h-12 w-12 mx-auto mb-3" />
            <p>No conversation history yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {conversations.map((conversation) => (
              <div key={conversation.id} className="border border-slate-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Badge className={cn("text-xs", providerColors[conversation.provider] || "bg-slate-100 text-slate-700")}>
                      {providerNames[conversation.provider] || conversation.provider}
                    </Badge>
                    <span className="text-xs text-slate-500">
                      {formatTimestamp(conversation.createdAt.toString())}
                    </span>
                  </div>
                </div>
                <div className="text-sm text-slate-600 mb-2">
                  <strong>Prompt:</strong> {truncateText(conversation.prompt)}
                </div>
                <div className="text-sm text-slate-500">
                  <strong>Response:</strong> {truncateText(conversation.response)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Card>
  );
}
