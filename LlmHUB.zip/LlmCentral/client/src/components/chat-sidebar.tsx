import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Plus, MessageSquare, Trash2, Calendar } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import type { ChatThread } from "@shared/schema";

interface ChatSidebarProps {
  selectedThreadId: number | null;
  onThreadSelect: (threadId: number | null) => void;
  onNewChat: () => void;
}

const providerColors: Record<string, string> = {
  openai: "bg-emerald-100 text-emerald-700",
  claude: "bg-amber-100 text-amber-700",
  gemini: "bg-blue-100 text-blue-700",
  perplexity: "bg-indigo-100 text-indigo-700",
};

const providerNames: Record<string, string> = {
  openai: "OpenAI",
  claude: "Claude",
  gemini: "Gemini",
  perplexity: "Perplexity",
};

export function ChatSidebar({ selectedThreadId, onThreadSelect, onNewChat }: ChatSidebarProps) {
  const queryClient = useQueryClient();

  const { data: threads = [], isLoading } = useQuery<ChatThread[]>({
    queryKey: ["/api/threads"],
  });

  const deleteThreadMutation = useMutation({
    mutationFn: async (threadId: number) => {
      await apiRequest("DELETE", `/api/threads/${threadId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/threads"] });
      if (selectedThreadId) {
        onThreadSelect(null);
      }
    },
  });

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 86400000) return "Today";
    if (diff < 172800000) return "Yesterday";
    if (diff < 604800000) return `${Math.floor(diff / 86400000)} days ago`;
    return date.toLocaleDateString();
  };

  const truncateTitle = (title: string, maxLength: number = 40) => {
    if (title.length <= maxLength) return title;
    return title.substring(0, maxLength) + "...";
  };

  return (
    <Card className="h-full flex flex-col">
      <div className="p-4 border-b border-slate-200">
        <Button 
          onClick={onNewChat}
          className="w-full flex items-center justify-center space-x-2"
        >
          <Plus className="h-4 w-4" />
          <span>New Chat</span>
        </Button>
      </div>
      
      <div className="p-4 border-b border-slate-200">
        <h2 className="text-sm font-semibold text-slate-600 flex items-center">
          <MessageSquare className="h-4 w-4 mr-2" />
          Recent Conversations
        </h2>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-2">
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="h-16 bg-slate-200 rounded-lg"></div>
                </div>
              ))}
            </div>
          ) : threads.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              <MessageSquare className="h-8 w-8 mx-auto mb-2" />
              <p className="text-sm">No conversations yet</p>
            </div>
          ) : (
            <div className="space-y-1">
              {threads.map((thread) => (
                <div
                  key={thread.id}
                  className={cn(
                    "group relative p-3 rounded-lg cursor-pointer transition-all duration-200 border",
                    selectedThreadId === thread.id
                      ? "bg-blue-50 border-blue-200"
                      : "hover:bg-slate-50 border-transparent"
                  )}
                  onClick={() => onThreadSelect(thread.id)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <Badge className={cn("text-xs", providerColors[thread.provider] || "bg-slate-100 text-slate-700")}>
                          {providerNames[thread.provider] || thread.provider}
                        </Badge>
                        {thread.model && (
                          <span className="text-xs text-slate-500">{thread.model}</span>
                        )}
                      </div>
                      <h3 className="text-sm font-medium text-slate-900 truncate">
                        {truncateTitle(thread.title)}
                      </h3>
                      <div className="flex items-center text-xs text-slate-500 mt-1">
                        <Calendar className="h-3 w-3 mr-1" />
                        {formatDate(thread.updatedAt.toString())}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6 p-0 text-slate-400 hover:text-red-600"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteThreadMutation.mutate(thread.id);
                      }}
                      disabled={deleteThreadMutation.isPending}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </ScrollArea>
    </Card>
  );
}