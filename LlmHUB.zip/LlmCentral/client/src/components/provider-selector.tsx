import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export interface Provider {
  id: "openai" | "claude" | "gemini" | "perplexity";
  name: string;
  description: string;
  icon: string;
  color: string;
}

const providers: Provider[] = [
  {
    id: "openai",
    name: "OpenAI",
    description: "GPT-4, GPT-3.5",
    icon: "🧠",
    color: "bg-emerald-500",
  },
  {
    id: "claude",
    name: "Claude",
    description: "Anthropic AI",
    icon: "💬",
    color: "bg-amber-500",
  },
  {
    id: "gemini",
    name: "Gemini",
    description: "Google AI",
    icon: "⭐",
    color: "bg-blue-500",
  },
  {
    id: "perplexity",
    name: "Perplexity",
    description: "Research AI",
    icon: "🔍",
    color: "bg-indigo-500",
  },
];

interface ProviderSelectorProps {
  selectedProvider: string;
  onProviderChange: (provider: string) => void;
}

export function ProviderSelector({ selectedProvider, onProviderChange }: ProviderSelectorProps) {
  return (
    <Card className="p-6 mb-8">
      <h2 className="text-lg font-semibold text-slate-900 mb-4">Select AI Provider</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {providers.map((provider) => (
          <button
            key={provider.id}
            onClick={() => onProviderChange(provider.id)}
            className={cn(
              "flex items-center space-x-3 p-4 rounded-lg border-2 transition-all duration-200",
              selectedProvider === provider.id
                ? "border-blue-500 bg-blue-50 shadow-sm"
                : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"
            )}
          >
            <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center text-white text-xl", provider.color)}>
              {provider.icon}
            </div>
            <div className="text-left">
              <div className="font-medium text-slate-900">{provider.name}</div>
              <div className="text-sm text-slate-500">{provider.description}</div>
            </div>
          </button>
        ))}
      </div>
    </Card>
  );
}
