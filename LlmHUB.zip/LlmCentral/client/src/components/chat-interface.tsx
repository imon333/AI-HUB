import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Send, Paperclip, User, Bot, X } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { cn } from "@/lib/utils";
import type { Message } from "@shared/schema";

interface ChatInterfaceProps {
  threadId: number | null;
  provider: string;
  onProviderChange: (provider: string) => void;
}

const openaiModels = [
  { id: "gpt-4o", name: "GPT-4o" },
  { id: "gpt-4", name: "GPT-4" },
  { id: "gpt-3.5-turbo", name: "GPT-3.5 Turbo" },
];

const providerNames: Record<string, string> = {
  openai: "OpenAI",
  claude: "Claude",
  gemini: "Gemini",
  perplexity: "Perplexity",
};

export function ChatInterface({ threadId, provider, onProviderChange }: ChatInterfaceProps) {
  const [prompt, setPrompt] = useState("");
  const [selectedModel, setSelectedModel] = useState("gpt-4o");
  const [attachments, setAttachments] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  const { data: messages = [], isLoading: messagesLoading } = useQuery<Message[]>({
    queryKey: ["/api/threads", threadId, "messages"],
    enabled: !!threadId,
    queryFn: async () => {
      if (!threadId) return [];
      const response = await fetch(`/api/threads/${threadId}/messages`);
      if (!response.ok) throw new Error('Failed to fetch messages');
      return response.json();
    },
  });

  const askMutation = useMutation({
    mutationFn: async (data: { 
      provider: string; 
      prompt: string; 
      threadId?: number; 
      model?: string;
      attachments?: { name: string; type: string; size: number; data: string }[];
    }) => {
      const response = await apiRequest("POST", "/api/ask", data);
      return response.json();
    },
    onSuccess: () => {
      setPrompt("");
      setAttachments([]);
      queryClient.invalidateQueries({ queryKey: ["/api/threads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/threads", threadId, "messages"] });
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, askMutation.isPending]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const validFiles = files.filter(file => {
      const isValidType = file.type.startsWith('text/') || 
                         file.type === 'application/pdf' ||
                         file.type === 'application/json' ||
                         file.type === 'text/plain';
      const isValidSize = file.size <= 10 * 1024 * 1024; // 10MB limit
      return isValidType && isValidSize;
    });
    
    setAttachments(prev => [...prev, ...validFiles]);
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || askMutation.isPending) return;

    const processedAttachments = await Promise.all(
      attachments.map(async (file) => {
        const data = await file.text();
        return {
          name: file.name,
          type: file.type,
          size: file.size,
          data: data,
        };
      })
    );

    await askMutation.mutateAsync({
      provider,
      prompt: prompt.trim(),
      threadId: threadId || undefined,
      model: provider === "openai" ? selectedModel : undefined,
      attachments: processedAttachments.length > 0 ? processedAttachments : undefined,
    });
  };

  const formatTimestamp = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-slate-200 bg-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Select value={provider} onValueChange={onProviderChange}>
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="openai">OpenAI</SelectItem>
                <SelectItem value="claude">Claude</SelectItem>
                <SelectItem value="gemini">Gemini</SelectItem>
                <SelectItem value="perplexity">Perplexity</SelectItem>
              </SelectContent>
            </Select>
            
            {provider === "openai" && (
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {openaiModels.map((model) => (
                    <SelectItem key={model.id} value={model.id}>
                      {model.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          
          <Badge variant="outline">
            {threadId ? `Thread ${threadId}` : "New Conversation"}
          </Badge>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        {threadId && messagesLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-slate-400" />
          </div>
        ) : messages.length === 0 && !threadId ? (
          <div className="flex flex-col items-center justify-center h-full text-slate-400">
            <Bot className="h-16 w-16 mb-4" />
            <h3 className="text-lg font-medium mb-2">Start a new conversation</h3>
            <p className="text-center text-sm">Choose a provider and send a message to begin</p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn(
                  "flex space-x-3",
                  message.role === "user" ? "justify-end" : "justify-start"
                )}
              >
                <div
                  className={cn(
                    "max-w-3xl rounded-lg p-4",
                    message.role === "user"
                      ? "bg-blue-500 text-white"
                      : "bg-slate-100 text-slate-900"
                  )}
                >
                  <div className="flex items-center space-x-2 mb-2">
                    {message.role === "user" ? (
                      <User className="h-4 w-4" />
                    ) : (
                      <Bot className="h-4 w-4" />
                    )}
                    <span className="text-sm font-medium">
                      {message.role === "user" ? "You" : providerNames[provider] || provider}
                    </span>
                    <span className="text-xs opacity-70">
                      {formatTimestamp(message.createdAt.toString())}
                    </span>
                  </div>
                  
                  {message.attachments && message.attachments.length > 0 && (
                    <div className="mb-3 space-y-1">
                      {message.attachments.map((attachment, index) => (
                        <div key={index} className="flex items-center space-x-2 text-xs opacity-70">
                          <Paperclip className="h-3 w-3" />
                          <span>{attachment.name}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  <div className="whitespace-pre-wrap leading-relaxed">
                    {message.content}
                  </div>
                </div>
              </div>
            ))}
            
            {askMutation.isPending && (
              <div className="flex justify-start">
                <div className="bg-slate-100 rounded-lg p-4 max-w-3xl">
                  <div className="flex items-center space-x-2 mb-2">
                    <Bot className="h-4 w-4" />
                    <span className="text-sm font-medium">{providerNames[provider] || provider}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span className="text-sm text-slate-600">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
        )}
      </ScrollArea>

      {/* Input */}
      <div className="p-4 border-t border-slate-200 bg-white">
        {attachments.length > 0 && (
          <div className="mb-3 flex flex-wrap gap-2">
            {attachments.map((file, index) => (
              <div key={index} className="flex items-center space-x-2 bg-slate-100 rounded-lg px-3 py-1">
                <Paperclip className="h-3 w-3" />
                <span className="text-xs">{file.name}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-4 w-4 p-0 hover:bg-slate-200"
                  onClick={() => removeAttachment(index)}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="flex space-x-2">
          <div className="flex-1 relative">
            <Textarea
              placeholder="Type your message here..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="min-h-[60px] resize-none pr-12"
              disabled={askMutation.isPending}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
            />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              className="absolute right-2 top-2 h-8 w-8 p-0"
              onClick={() => fileInputRef.current?.click()}
              disabled={askMutation.isPending}
            >
              <Paperclip className="h-4 w-4" />
            </Button>
          </div>
          
          <Button 
            type="submit" 
            disabled={!prompt.trim() || askMutation.isPending}
            className="h-[60px] px-6"
          >
            {askMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </form>
        
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".txt,.pdf,.json,.md,.csv"
          onChange={handleFileUpload}
          className="hidden"
        />
        
        <p className="text-xs text-slate-500 mt-2">
          Press Enter to send, Shift+Enter for new line. Attach documents up to 10MB.
        </p>
      </div>
    </div>
  );
}