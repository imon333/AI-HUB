import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Send, Edit } from "lucide-react";

interface PromptInputProps {
  selectedProvider: string;
  onSubmit: (prompt: string) => Promise<void>;
  isLoading: boolean;
  error: string | null;
}

const providerNames: Record<string, string> = {
  openai: "OpenAI",
  claude: "Claude",
  gemini: "Gemini",
  perplexity: "Perplexity",
};

export function PromptInput({ selectedProvider, onSubmit, isLoading, error }: PromptInputProps) {
  const [prompt, setPrompt] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isLoading) return;
    
    await onSubmit(prompt.trim());
    setPrompt("");
  };

  return (
    <Card className="h-fit">
      <div className="p-6 border-b border-slate-100">
        <h2 className="text-lg font-semibold text-slate-900 flex items-center">
          <Edit className="text-blue-500 mr-2 h-5 w-5" />
          Your Prompt
        </h2>
        <p className="text-sm text-slate-500 mt-1">Enter your message for the selected AI provider</p>
      </div>
      
      <div className="p-6">
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <Textarea
              placeholder="Type your message here..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="min-h-[128px] resize-none"
              disabled={isLoading}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="text-sm text-slate-500">
              {providerNames[selectedProvider] || selectedProvider} selected
            </div>
            <Button 
              type="submit" 
              disabled={!prompt.trim() || isLoading}
              className="flex items-center space-x-2"
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <Send className="h-4 w-4" />
                  <span>Send Prompt</span>
                </>
              )}
            </Button>
          </div>
        </form>

        {error && (
          <div className="mt-4 p-4 bg-red-50 rounded-lg border border-red-200">
            <div className="flex items-center space-x-3">
              <div className="text-red-500">⚠️</div>
              <span className="text-red-700 font-medium">{error}</span>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}
