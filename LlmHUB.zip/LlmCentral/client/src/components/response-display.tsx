import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, MessageCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface ResponseDisplayProps {
  response: string | null;
  provider: string | null;
  timestamp: Date | null;
  isLoading: boolean;
}

const providerColors: Record<string, string> = {
  openai: "bg-emerald-100 text-emerald-700",
  claude: "bg-amber-100 text-amber-700",
  gemini: "bg-blue-100 text-blue-700",
  perplexity: "bg-indigo-100 text-indigo-700",
};

const providerNames: Record<string, string> = {
  openai: "OpenAI",
  claude: "Claude",
  gemini: "Gemini",
  perplexity: "Perplexity",
};

export function ResponseDisplay({ response, provider, timestamp, isLoading }: ResponseDisplayProps) {
  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return "Just now";
    if (diff < 3600000) return `${Math.floor(diff / 60000)} minutes ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)} hours ago`;
    return date.toLocaleDateString();
  };

  return (
    <Card className="h-fit">
      <div className="p-6 border-b border-slate-100">
        <h2 className="text-lg font-semibold text-slate-900 flex items-center">
          <Bot className="text-emerald-500 mr-2 h-5 w-5" />
          AI Response
        </h2>
        <p className="text-sm text-slate-500 mt-1">The AI's response will appear here</p>
      </div>
      
      <div className="p-6">
        <div className="min-h-[200px]">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center h-48 text-slate-400">
              <div className="animate-pulse">
                <Bot className="h-12 w-12 mb-4" />
              </div>
              <p className="text-center">Processing your request...</p>
            </div>
          ) : response && provider ? (
            <div>
              <div className="mb-4 pb-4 border-b border-slate-100">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-slate-600">Response from</span>
                  <Badge className={cn("text-xs", providerColors[provider] || "bg-slate-100 text-slate-700")}>
                    {providerNames[provider] || provider}
                  </Badge>
                </div>
                {timestamp && (
                  <div className="text-xs text-slate-500">{formatTimestamp(timestamp)}</div>
                )}
              </div>
              
              <div className="prose prose-slate max-w-none">
                <div className="text-slate-700 leading-relaxed whitespace-pre-wrap">
                  {response}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-48 text-slate-400">
              <MessageCircle className="h-12 w-12 mb-4" />
              <p className="text-center">No response yet. Send a prompt to get started!</p>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
