import { useState } from "react";
import { ChatSidebar } from "@/components/chat-sidebar";
import { ChatInterface } from "@/components/chat-interface";

export default function Chat() {
  const [selectedThreadId, setSelectedThreadId] = useState<number | null>(null);
  const [selectedProvider, setSelectedProvider] = useState("openai");

  const handleNewChat = () => {
    setSelectedThreadId(null);
  };

  const handleThreadSelect = (threadId: number | null) => {
    setSelectedThreadId(threadId);
  };

  return (
    <div className="h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <div className="w-80 border-r border-slate-200 bg-white">
        <ChatSidebar
          selectedThreadId={selectedThreadId}
          onThreadSelect={handleThreadSelect}
          onNewChat={handleNewChat}
        />
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        <ChatInterface
          threadId={selectedThreadId}
          provider={selectedProvider}
          onProviderChange={setSelectedProvider}
        />
      </div>
    </div>
  );
}