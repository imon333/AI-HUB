import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ProviderSelector } from "@/components/provider-selector";
import { PromptInput } from "@/components/prompt-input";
import { ResponseDisplay } from "@/components/response-display";
import { ConversationHistory } from "@/components/conversation-history";
import { apiRequest } from "@/lib/queryClient";
import { Shield, Code, Key } from "lucide-react";

interface AskResponse {
  response: string;
}

export default function Home() {
  const [selectedProvider, setSelectedProvider] = useState("openai");
  const [currentResponse, setCurrentResponse] = useState<string | null>(null);
  const [responseTimestamp, setResponseTimestamp] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const queryClient = useQueryClient();

  const askMutation = useMutation({
    mutationFn: async (data: { provider: string; prompt: string }): Promise<AskResponse> => {
      const response = await apiRequest("POST", "/api/ask", data);
      return response.json();
    },
    onSuccess: (data) => {
      setCurrentResponse(data.response);
      setResponseTimestamp(new Date());
      setError(null);
      // Invalidate conversations to refresh history
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
    onError: (error: any) => {
      setError(error.message);
    },
  });

  const handleSubmit = async (prompt: string) => {
    setError(null);
    await askMutation.mutateAsync({
      provider: selectedProvider,
      prompt,
    });
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-500 p-2 rounded-lg">
                <div className="text-white text-xl">🤖</div>
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900">LLM Hub</h1>
                <p className="text-sm text-slate-500">Multi-Provider AI Interface</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-slate-600 flex items-center">
                <Shield className="text-emerald-500 mr-1 h-4 w-4" />
                Secure API Management
              </span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Provider Selection */}
        <ProviderSelector
          selectedProvider={selectedProvider}
          onProviderChange={setSelectedProvider}
        />

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Prompt Input */}
          <PromptInput
            selectedProvider={selectedProvider}
            onSubmit={handleSubmit}
            isLoading={askMutation.isPending}
            error={error}
          />

          {/* Response Display */}
          <ResponseDisplay
            response={currentResponse}
            provider={selectedProvider}
            timestamp={responseTimestamp}
            isLoading={askMutation.isPending}
          />
        </div>

        {/* Conversation History */}
        <ConversationHistory />
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between">
            <div className="text-sm text-slate-500 flex items-center">
              <Code className="mr-1 h-4 w-4" />
              Built with Node.js, Express, and Tailwind CSS
            </div>
            <div className="flex items-center space-x-4 mt-2 sm:mt-0">
              <span className="text-sm text-slate-500 flex items-center">
                <Key className="text-amber-500 mr-1 h-4 w-4" />
                API Keys: Securely managed via .env
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
