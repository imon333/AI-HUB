# AI Chat Application

## Overview

This is a full-stack AI chat application with a ChatGPT-like interface that allows users to interact with multiple AI providers (OpenAI, Claude, Gemini, and Perplexity) through threaded conversations. The application features document upload capabilities, conversation history with sidebar navigation, model selection for OpenAI, and persistent chat threads stored in PostgreSQL.

## System Architecture

### Frontend Architecture

- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture

- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM configured for PostgreSQL
- **Database**: PostgreSQL (configured but using in-memory storage for development)
- **Session Management**: Express sessions with PostgreSQL store support
- **API Design**: RESTful endpoints with typed request/response schemas

### Build System

- **Development**: Vite dev server with HMR and proxy to Express backend
- **Production**: Vite builds frontend assets, esbuild bundles backend
- **Deployment**: Configured for Replit autoscale deployment

## Key Components

### AI Service Integration

The application integrates with four major AI providers:

1. **OpenAI**: GPT-4o model with chat completions API
2. **Claude**: Anthropic's Claude Sonnet 4 (latest model)
3. **Gemini**: Google's Gemini Pro model
4. **Perplexity**: Llama 3.1 Sonar model for research queries

Each service has its own module with error handling for API keys and rate limits.

### Database Schema

- **Users Table**: Basic user authentication (id, username, password)
- **Chat Threads Table**: Conversation threads (id, title, provider, model, created/updated timestamps)
- **Messages Table**: Individual messages in threads (id, threadId, role, content, attachments, timestamp)
- **Conversations Table**: Legacy single exchanges (maintained for backwards compatibility)

Uses PostgreSQL with Drizzle ORM for persistent storage of threaded conversations and file attachments.

### UI Components

- **Chat Sidebar**: Thread list with provider badges, timestamps, and delete functionality
- **Chat Interface**: ChatGPT-like interface with message bubbles, model selection, and file uploads
- **Provider Selector**: Dropdown for choosing AI providers with model options for OpenAI
- **Document Upload**: Support for text files, PDFs, JSON, and other documents up to 10MB
- **Legacy Components**: Original interface available at `/legacy` route for backwards compatibility

## Data Flow

1. User creates new chat or selects existing thread from sidebar
2. User chooses AI provider and model (OpenAI offers multiple models)
3. User types message and optionally attaches documents
4. Frontend sends POST request to `/api/ask` with thread context
5. Backend creates/updates thread and stores user message
6. AI service processes request with conversation context
7. Backend stores AI response and updates thread timestamp
8. Frontend displays threaded conversation with message history

## External Dependencies

### AI Providers

- **OpenAI SDK**: `openai` package for GPT models
- **Anthropic SDK**: `@anthropic-ai/sdk` for Claude models
- **Google Generative AI**: `@google/generative-ai` for Gemini
- **Perplexity**: Direct API calls using fetch

### Database & ORM

- **Drizzle ORM**: Type-safe SQL toolkit with PostgreSQL support
- **Neon Database**: Serverless PostgreSQL driver
- **Connection Pooling**: Built-in connection management

### Development Tools

- **TypeScript**: Full type safety across frontend and backend
- **Zod**: Runtime type validation for API schemas
- **ESBuild**: Fast bundling for production builds
- **Replit Integration**: Development environment optimizations

## Deployment Strategy

The application is configured for deployment on Replit's autoscale platform:

- **Build Process**: `npm run build` creates optimized bundles
- **Production Server**: Serves static files and API routes on port 5000
- **Environment Variables**: Requires API keys for each AI provider
- **Database**: Ready to connect to PostgreSQL via `DATABASE_URL`

The deployment handles both development (with Vite dev server) and production (with Express serving static files) environments seamlessly.

## Changelog

```
Changelog:
- June 15, 2025. Initial setup with single-exchange interface
- June 15, 2025. Transformed to ChatGPT-like interface with:
  * Threaded conversations with persistent storage
  * Document upload capabilities (text, PDF, JSON up to 10MB)
  * OpenAI model selection (GPT-4o, GPT-4, GPT-3.5-turbo)
  * Chat sidebar with conversation history
  * PostgreSQL database with Drizzle ORM
  * Legacy interface preserved at /legacy route
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```