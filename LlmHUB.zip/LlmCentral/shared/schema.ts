import { pgTable, text, serial, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const chatThreads = pgTable("chat_threads", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  provider: text("provider").notNull(),
  model: text("model"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  threadId: integer("thread_id").references(() => chatThreads.id).notNull(),
  role: text("role").notNull(), // 'user' or 'assistant'
  content: text("content").notNull(),
  attachments: jsonb("attachments").$type<{ name: string; type: string; size: number; data: string }[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const conversations = pgTable("conversations", {
  id: serial("id").primaryKey(),
  provider: text("provider").notNull(),
  prompt: text("prompt").notNull(),
  response: text("response").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const chatThreadsRelations = relations(chatThreads, ({ many }) => ({
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  thread: one(chatThreads, {
    fields: [messages.threadId],
    references: [chatThreads.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertChatThreadSchema = createInsertSchema(chatThreads).pick({
  title: true,
  provider: true,
  model: true,
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  threadId: true,
  role: true,
  content: true,
}).extend({
  attachments: z.array(z.object({
    name: z.string(),
    type: z.string(),
    size: z.number(),
    data: z.string(),
  })).optional(),
});

export const insertConversationSchema = createInsertSchema(conversations).pick({
  provider: true,
  prompt: true,
  response: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertChatThread = z.infer<typeof insertChatThreadSchema>;
export type ChatThread = typeof chatThreads.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;

// API schemas
export const askRequestSchema = z.object({
  provider: z.enum(["openai", "claude", "gemini", "perplexity"]),
  prompt: z.string().min(1, "Prompt is required"),
  threadId: z.number().optional(),
  model: z.string().optional(),
  attachments: z.array(z.object({
    name: z.string(),
    type: z.string(),
    size: z.number(),
    data: z.string(),
  })).optional(),
});

export type AskRequest = z.infer<typeof askRequestSchema>;

export const createThreadSchema = z.object({
  title: z.string().min(1, "Title is required"),
  provider: z.enum(["openai", "claude", "gemini", "perplexity"]),
  model: z.string().optional(),
});

export type CreateThreadRequest = z.infer<typeof createThreadSchema>;
