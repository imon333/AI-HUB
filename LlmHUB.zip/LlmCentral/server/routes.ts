import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { askRequestSchema, createThreadSchema } from "@shared/schema";
import { askOpenAI } from "./services/openai";
import { askClaude } from "./services/claude";
import { askGemini } from "./services/gemini";
import { askPerplexity } from "./services/perplexity";

export async function registerRoutes(app: Express): Promise<Server> {
  // Create new chat thread
  app.post("/api/threads", async (req, res) => {
    try {
      const { title, provider, model } = createThreadSchema.parse(req.body);
      const thread = await storage.createChatThread({ title, provider, model });
      res.json(thread);
    } catch (error: any) {
      console.error("Error in POST /api/threads:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get all chat threads
  app.get("/api/threads", async (req, res) => {
    try {
      const threads = await storage.getChatThreads(50);
      res.json(threads);
    } catch (error: any) {
      console.error("Error in GET /api/threads:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get messages for a specific thread
  app.get("/api/threads/:id/messages", async (req, res) => {
    try {
      const threadId = parseInt(req.params.id);
      const messages = await storage.getThreadMessages(threadId);
      res.json(messages);
    } catch (error: any) {
      console.error("Error in GET /api/threads/:id/messages:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Delete a chat thread
  app.delete("/api/threads/:id", async (req, res) => {
    try {
      const threadId = parseInt(req.params.id);
      await storage.deleteChatThread(threadId);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error in DELETE /api/threads/:id:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Ask endpoint - handles requests to all LLM providers with thread support
  app.post("/api/ask", async (req, res) => {
    try {
      const { provider, prompt, threadId, model, attachments } = askRequestSchema.parse(req.body);

      // If no threadId provided, create a new thread
      let actualThreadId = threadId;
      if (!actualThreadId) {
        const title = prompt.length > 50 ? prompt.substring(0, 47) + "..." : prompt;
        const thread = await storage.createChatThread({ title, provider, model });
        actualThreadId = thread.id;
      }

      // Store user message
      await storage.createMessage({
        threadId: actualThreadId,
        role: "user",
        content: prompt,
        attachments: attachments || undefined,
      });

      let response: string;
      
      switch (provider) {
        case "openai":
          response = await askOpenAI(prompt, model);
          break;
        case "claude":
          response = await askClaude(prompt);
          break;
        case "gemini":
          response = await askGemini(prompt);
          break;
        case "perplexity":
          response = await askPerplexity(prompt);
          break;
        default:
          return res.status(400).json({ error: "Invalid provider" });
      }

      // Store AI response
      await storage.createMessage({
        threadId: actualThreadId,
        role: "assistant",
        content: response,
      });

      // Store in old conversation format for backwards compatibility
      await storage.createConversation({
        provider,
        prompt,
        response,
      });

      res.json({ response, threadId: actualThreadId });
    } catch (error: any) {
      console.error("Error in /api/ask:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get conversation history
  app.get("/api/conversations", async (req, res) => {
    try {
      const conversations = await storage.getRecentConversations(20);
      res.json(conversations);
    } catch (error: any) {
      console.error("Error in /api/conversations:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Clear conversation history
  app.delete("/api/conversations", async (req, res) => {
    try {
      await storage.clearConversations();
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error in DELETE /api/conversations:", error);
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
