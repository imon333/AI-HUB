import { 
  users, conversations, chatThreads, messages,
  type User, type InsertUser, type Conversation, type InsertConversation,
  type ChatThread, type InsertChatThread, type Message, type InsertMessage
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  getRecentConversations(limit?: number): Promise<Conversation[]>;
  clearConversations(): Promise<void>;
  
  // New thread-based methods
  createChatThread(thread: InsertChatThread): Promise<ChatThread>;
  getChatThreads(limit?: number): Promise<ChatThread[]>;
  getChatThread(id: number): Promise<ChatThread | undefined>;
  updateChatThread(id: number, updates: Partial<InsertChatThread>): Promise<ChatThread>;
  deleteChatThread(id: number): Promise<void>;
  
  // Message methods
  createMessage(message: InsertMessage): Promise<Message>;
  getThreadMessages(threadId: number): Promise<Message[]>;
  deleteThreadMessages(threadId: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const [conversation] = await db
      .insert(conversations)
      .values(insertConversation)
      .returning();
    return conversation;
  }

  async getRecentConversations(limit: number = 10): Promise<Conversation[]> {
    return await db
      .select()
      .from(conversations)
      .orderBy(desc(conversations.createdAt))
      .limit(limit);
  }

  async clearConversations(): Promise<void> {
    await db.delete(conversations);
  }

  // Thread methods
  async createChatThread(insertThread: InsertChatThread): Promise<ChatThread> {
    const [thread] = await db
      .insert(chatThreads)
      .values(insertThread)
      .returning();
    return thread;
  }

  async getChatThreads(limit: number = 20): Promise<ChatThread[]> {
    return await db
      .select()
      .from(chatThreads)
      .orderBy(desc(chatThreads.updatedAt))
      .limit(limit);
  }

  async getChatThread(id: number): Promise<ChatThread | undefined> {
    const [thread] = await db.select().from(chatThreads).where(eq(chatThreads.id, id));
    return thread || undefined;
  }

  async updateChatThread(id: number, updates: Partial<InsertChatThread>): Promise<ChatThread> {
    const [thread] = await db
      .update(chatThreads)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(chatThreads.id, id))
      .returning();
    return thread;
  }

  async deleteChatThread(id: number): Promise<void> {
    await db.delete(messages).where(eq(messages.threadId, id));
    await db.delete(chatThreads).where(eq(chatThreads.id, id));
  }

  // Message methods
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values({
        threadId: insertMessage.threadId,
        role: insertMessage.role,
        content: insertMessage.content,
        attachments: insertMessage.attachments || null,
      })
      .returning();
    return message;
  }

  async getThreadMessages(threadId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.threadId, threadId))
      .orderBy(messages.createdAt);
  }

  async deleteThreadMessages(threadId: number): Promise<void> {
    await db.delete(messages).where(eq(messages.threadId, threadId));
  }
}

export const storage = new DatabaseStorage();
