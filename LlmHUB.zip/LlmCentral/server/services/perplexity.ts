export async function askPerplexity(prompt: string): Promise<string> {
  const apiKey = process.env.PERPLEXITY_API_KEY || process.env.PERPLEXITY_API_KEY_ENV_VAR;
  
  if (!apiKey) {
    throw new Error("Perplexity API key is not configured. Please set PERPLEXITY_API_KEY in your environment variables.");
  }

  try {
    const response = await fetch('https://api.perplexity.ai/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'llama-3.1-sonar-small-128k-online',
        messages: [
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 1000,
        temperature: 0.2,
        top_p: 0.9,
        stream: false,
      }),
    });

    if (!response.ok) {
      if (response.status === 401) {
        throw new Error("Invalid Perplexity API key. Please check your API key configuration.");
      }
      throw new Error(`Perplexity API returned status ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error("No response received from Perplexity");
    }

    return content;
  } catch (error: any) {
    if (error.message.includes("API key")) {
      throw error;
    }
    throw new Error(`Perplexity API error: ${error.message}`);
  }
}
