import { GoogleGenerativeAI } from '@google/generative-ai';

const genAI = new GoogleGenerativeAI(
  process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY_ENV_VAR || ""
);

export async function askGemini(prompt: string): Promise<string> {
  const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY_ENV_VAR;
  
  if (!apiKey) {
    throw new Error("Gemini API key is not configured. Please set GEMINI_API_KEY in your environment variables.");
  }

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    if (!text) {
      throw new Error("No response received from Gemini");
    }

    return text;
  } catch (error: any) {
    if (error.status === 400 && error.message.includes("API_KEY_INVALID")) {
      throw new Error("Invalid Gemini API key. Please check your API key configuration.");
    }
    throw new Error(`Gemini API error: ${error.message}`);
  }
}
