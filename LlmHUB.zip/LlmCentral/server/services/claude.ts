import Anthropic from '@anthropic-ai/sdk';

// the newest Anthropic model is "claude-sonnet-4-20250514" which was released May 14, 2025. Use this by default unless user has already selected claude-3-7-sonnet-20250219
const anthropic = new Anthropic({
  apiKey: process.env.CLAUDE_API_KEY || process.env.ANTHROPIC_API_KEY || process.env.CLAUDE_API_KEY_ENV_VAR,
});

export async function askClaude(prompt: string): Promise<string> {
  const apiKey = process.env.CLAUDE_API_KEY || process.env.ANTHROPIC_API_KEY || process.env.CLAUDE_API_KEY_ENV_VAR;
  
  if (!apiKey) {
    throw new Error("Claude API key is not configured. Please set CLAUDE_API_KEY or ANTHROPIC_API_KEY in your environment variables.");
  }

  try {
    const message = await anthropic.messages.create({
      max_tokens: 1000,
      messages: [{ role: 'user', content: prompt }],
      model: 'claude-sonnet-4-20250514',
    });

    const content = message.content[0];
    if (content.type !== 'text') {
      throw new Error("Unexpected response format from Claude");
    }

    return content.text;
  } catch (error: any) {
    if (error.status === 401) {
      throw new Error("Invalid Claude API key. Please check your API key configuration.");
    }
    throw new Error(`Claude API error: ${error.message}`);
  }
}
